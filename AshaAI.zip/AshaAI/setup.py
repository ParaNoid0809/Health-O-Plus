from setuptools import find_packages, setup

setup(
    name = 'Generative AI Project:AshaAI',
    version= '0.0.1',
    author= 'Anshuman Behera & Sukriti Deb',
    author_email= 'anshumanbehera909@gmail.com & deb.sukriti19@gmail.com',
    packages= find_packages(),
    install_requires = []

)